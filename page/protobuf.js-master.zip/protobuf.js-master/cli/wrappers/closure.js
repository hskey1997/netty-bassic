(function($protobuf) {
    "use strict";

    $OUTPUT;

    return $root;
})(protobuf);
