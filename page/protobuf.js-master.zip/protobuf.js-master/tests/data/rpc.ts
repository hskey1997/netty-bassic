import * as test from "./rpc.js";
