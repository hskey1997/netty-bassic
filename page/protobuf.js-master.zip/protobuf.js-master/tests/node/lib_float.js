require("../../lib/float/tests"); // requires node for modified global envs
